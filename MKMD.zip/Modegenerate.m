%% 数据处理
clear;clc;
data = readtable("merged_data_filled3.csv", 'VariableNamingRule', 'preserve');
temp = data.("PRCP");
Data = temp()';  %  气温数据（每小时取一次）
Data=data;
%% 分解与模态计算
delt = 1;delay = 14;delx = 1;  % 每小时取一次数据，延时步数为8
avg = mean(Data,2);
[eigval,Modes1,bo] = H_DMD(Data-avg,delay);
omega = log(diag(eigval))./delt;
Freal=imag(omega)./(2*pi);
% Freal(Freal < 1e-10) = NaN;  % 将零值或极小值替换为 NaN
[T,Im]=sort((1./Freal),'descend');  % 得到频率（降序）
% max_T = 1/T(2);
omega=omega(Im); Modes1=Modes1(:,Im); bo=bo(Im);  % 对应模态（降序）

%% 生成具体的模态
[nbx,nbt]=size(Data);
time=(0:nbt-1)*delt;
mode1 = 1;mode2 = 716;  % 生成指定模态(已经按能量的降序进行排列了）
Psi=zeros(nbx,nbt,mode2-mode1+1);
res=[];
for i=mode1:mode2
    psi = zeros(1,nbt);
    omeganow = omega(i);
    bnow = bo(i);
    parfor t=1:length(time) 
        psi(:,t)=exp(omeganow*time(t))*bnow;  % 并行计算结果
    end
    psi = Modes1(1:nbx,i)*psi;
    Psi(:,:,i) = psi;  % 输出模态
    m = abs(psi);
    mag = mean(m(:)); %average amplitude
    res = [res mag];
end
res=res';
%% 绘图(模态实部（增长率））
FONTSIZE = 24;
TICKSIZE = 18;
mode1 = 256;
mode2 = 256;
for i = mode1:mode2
figure;  
plot(time , real(Psi(:,:,i)), 'LineWidth', 2); % Adjust LineWidth as needed  
title({['Koopman Mode #' num2str(i)], ...  
       ['Period=' num2str(T(i),'%.2f') ' 小时']}, 'Interpreter', 'latex');  
xlabel('Time [Minutes]', 'Interpreter', 'latex');  
ylabel('Real Part of $\psi$', 'Interpreter', 'latex');  
set(gca, 'TickLabelInterpreter', 'latex', 'FontSize', TICKSIZE);  
grid on;  
end

%% 模态三维图
FONTSIZE = 24;
TICKSIZE = 18;
mode1 = 12;
mode2 = 12;
[nbx,nbt] = size(Data);
distance = delx*size(Data,1);
for i = mode1:mode2
[X,Y]=meshgrid(time,linspace(0,distance,nbx));% Compute Mesh.
figure
s1=surfc(X,Y,real(Psi(:,:,i)));% Generate Surface Plot
set(s1,'LineStyle','none')% No Lines
title({['Koopman Mode #' num2str(i)  ],[ 'Period=' num2str(T(i),'%.2f')...
    ' 天    Growth/Decay Rate=' num2str(abs(exp(omega(i))),'%.4f')]})

title({['Koopman Mode #' num2str(i)  '      Period=' num2str(T(i),'%.2f')...
    ' 天']},'Interpreter','latex')

set(gca,'TickLabelInterpreter','latex','fontsize',TICKSIZE)
title(strcat('Koopman Mode #',num2str(i),'$,   Period=',num2str(T(i),'%.2f'),'天 $'),...
                     'fontsize',FONTSIZE,...
                     'Interpreter','Latex')

xlabel('Time [天]','Interpreter','latex'); 
ylabel('year','Interpreter','latex');
h=colorbar;
end
%% 创建实部与虚部的散点图
% 提取对角线上的元素
diag_eigval = diag(eigval);

% 计算原始特征值的实部、虚部和模
realPart = real(diag_eigval);
imagPart = imag(diag_eigval);
absEigval = abs(diag_eigval);

% 对特征值进行对数化处理
log_diag_eigval = log(diag_eigval);
log_realPart = real(log_diag_eigval);
log_imagPart = imag(log_diag_eigval);

% 设置颜色分类标准
colorStable = [0 0 1];  % 蓝色表示稳定
colorUnstable = [1 0 0];  % 红色表示不稳定
colorNeutral = [0 1 0];  % 绿色表示中性

% 初始化颜色数组
pointColors = zeros(length(diag_eigval), 3);

% 创建一个包含两个子图的图形窗口
figure;

% 绘制原始特征值的单位圆图
subplot(1, 2, 1);
hold on;

% 分类绘制原始特征值并记录颜色
for i = 1:length(diag_eigval)
    if absEigval(i) < 0.999  % 稳定
        pointColors(i, :) = colorStable;
        scatter(realPart(i), imagPart(i), 20, colorStable, 'filled');
    elseif absEigval(i) >= 0.999 && absEigval(i) <= 1.001  % 中性
        pointColors(i, :) = colorNeutral;
        scatter(realPart(i), imagPart(i), 20, colorNeutral, 'filled');
    else  % 不稳定
        pointColors(i, :) = colorUnstable;
        scatter(realPart(i), imagPart(i), 20, colorUnstable, 'filled');
    end
end

% 绘制单位圆
% theta = linspace(0, 2*pi, 100);
% plot(cos(theta), sin(theta), 'k--');  % 单位圆，虚线

% 设置图形属性
xlabel('Re(\lambda_i)');
ylabel('Im(\lambda_i)');
title('Eigenvalues Distribution on Unit Circle');
axis equal;
xlim([-1.2, 1.2]);
ylim([-1.2, 1.2]);
grid on;

% 绘制对数化特征值的图，以虚部为 x 轴
subplot(1, 2, 2);
hold on;

% 绘制对数化特征值，使用之前记录的颜色
for i = 1:length(log_diag_eigval)
    scatter(log_imagPart(i), log_realPart(i), 20, pointColors(i, :), 'filled');
end

% 设置图形属性
xlabel('Im(log(\lambda_i))');
ylabel('Re(log(\lambda_i))');
title('Logarithmized Eigenvalues Distribution');
xlim([-4, 4]);
ylim([-1.6, 0.2]);
grid on;

% 添加图例
hStable = scatter(nan, nan, 30, colorStable, 'filled');
hNeutral = scatter(nan, nan, 30, colorNeutral, 'filled');
hUnstable = scatter(nan, nan, 30, colorUnstable, 'filled');
legend([hStable, hNeutral, hUnstable], {'Stable', 'Neutral', 'Unstable'}, 'Location', 'best');

hold off;
%% 模态能量图
num_modes = size(Psi,3);  % 模态的数量  
energy = zeros(num_modes, 1);  % 初始化能量数组  

% 计算每个模态的能量  
for j = 1:num_modes  
    % 计算能量  
    energy(j) = norm(squeeze(Psi(:,:,j)), 'fro');  % 计算每个模态的 L2 范数能量  
end 
% % 计算每个模态的能量  
% for j = 1:num_modes  
%     % 计算能量  
%     energy(j) = norm(Modes1(:, j))^2;  % 计算每个模态的 L2 范数能量  
% end 
%energy = abs(eigval).^2;(特征向量法）

% 获取模态序号
num_modes = length(energy);
modes = 1:num_modes;

% 绘制折线图（无空心点）
figure;
plot(modes, energy, '-', 'LineWidth', 1);  % 使用线条绘制，无标记点
xlabel('Mode Number', 'Interpreter', 'latex');  % X轴标签
ylabel('Mode Energy', 'Interpreter', 'latex');  % Y轴标签
title('Mode Energy Distribution', 'Interpreter', 'latex');  % 图标题

% 设置图形属性
set(gca, 'TickLabelInterpreter', 'latex', 'FontSize', 12);  % 设置刻度字体
grid on;  % 添加网格线

%% 预测1 以周期为采样窗口
for f=min_f:min_f:max_f % Loop over Forecast Size Steps of 15 Mins
for s=min_s:min_s:max_s % Loop over Sampling Size in Steps of 15 Mins

P=[]; PE=[]; E=[]; I=[]; R=[]; Ptrue=[];

for t=s:f:nbt-f % Slide Window
if mod(t,100)==0 % Display Progress
disp(['Delay=' num2str(delay) ' Forecasting Window=' num2str(f)...
    ' Sampling Window=' num2str(s) ' Current Time=' num2str(t)...
    ' Out of ' num2str(nbt-f)])
end
omega=[]; eigval=[]; Modes1=[]; bo=[]; % Clear 
Xdmd=[]; Xtrain=[]; det=[]; % Clear 
Xtrain=Data(:,t-s+1:t); % Training Data
Xfor=Data(:,t+1:t+f); % Ground Truth of Forecasted Data 
det=mean(Xtrain,2);% Compute and Store Time Average
delay=min(s-1);% Set Delays to Max Possible
[eigval,Modes1,bo] = H_DMD(Xtrain-det,delay); % Compute HDMD
omega=log(diag(eigval))./delt; Modes1=Modes1(1:nbx,:);
parfor time=1:s+f
Xdmd(:,time)=diag(exp(omega.*(time-1)))*bo;% Evolve
end
Xdmd=Modes1*Xdmd; % Compute Reconstructed & Forecasted Data
Xdmd=real(Xdmd+det);% Add the Average Back in
P=[P Xdmd(:,s+1:end)];% Only Store the Forecast
Ptrue=[Ptrue Xfor];
end % Window Sliding

Prediction{f,s}=P;% Store Entire Forecast for These f,w Values
E=P-Data(:,s+1:s+size(P,2));% Compute Error Matrix
I=size(E,1)*size(E,2);% Get Total # Elements in Error matrix
MAE(f,s)=sum(sum(abs(E)))./I;% Compute MAE
MRE(f,s)=sum(sum(abs(E)./Data(:,s+1:s+size(P,2))))./I;% Compute MRE
RMSE(f,s)=sqrt(sum(sum(E.^2))./I);% Compute RMSE


SAE{f,s}=abs(E)./mean(Data(:,s+1:s+size(P,2)),2);% Compute SAE
TMAE{f,s}=mean(abs(E),1);% Compute TMAE
SMAE{f,s}=mean(abs(E),2);% Compute SMAE
AvgTMAE(f,s)=mean(TMAE{f,s});% Compute Avg of TMAE
AvgSMAE(f,s)=mean(SMAE{f,s});% Compute Avg of SMAE

end % End Sampling Window Loop
end % End Forecasting WIndow Loop

%%
tau_autocorr = autocorrelation_method_multi(data);
fprintf('自相关法选择的延时步数: %d\n', tau_autocorr);
tau_mutual_info = mutual_information_method_multi(data);
fprintf('最小互信息法选择的延时步数: %d\n', tau_mutual_info);
function tau_autocorr = autocorrelation_method_multi(x)
    num_dim = size(x, 1);
    max_tau = 61;
    all_min_tau = zeros(num_dim, 1);
    for d = 1:num_dim
        [acf, lags] = autocorr(x(d, :));
        valid_lags = lags > 0 & lags <= max_tau;
        valid_acf = acf(valid_lags);
        [~, idx] = min(valid_acf);
        % 获取有效滞后索引
        valid_indices = find(valid_lags);
        % 取对应位置的索引
        all_min_tau(d) = valid_indices(idx);
    end
    tau_autocorr = round(mean(all_min_tau));
end

function tau_mutual_info = mutual_information_method_multi(x)
    num_dim = size(x, 1);
    max_tau = 61;
    all_mi = zeros(num_dim, max_tau);
    for d = 1:num_dim
        for tau = 1:max_tau
            y = circshift(x(d, :), tau);
            all_mi(d, tau) = mutualinfo(x(d, :), y);
        end
    end
    % 这里简单取各维度最小互信息对应的平均滞后作为延时步数
    tau_per_dim = zeros(num_dim, 1);
    for d = 1:num_dim
        [~, idx] = min(all_mi(d, :));
        tau_per_dim(d) = idx;
    end
    tau_mutual_info = round(mean(tau_per_dim));
end
function mi = mutualinfo(x, y)
    % 简单的互信息计算示例，实际需要更复杂的概率密度估计
    bins = 10;
    H = hist3([x(:) y(:)], [bins bins]); % 仅接收一个输出参数
    Pxy = H / numel(x);
    Px = sum(Pxy, 2);
    Py = sum(Pxy, 1);
    mi = 0;
    for i = 1:bins
        for j = 1:bins
            if Pxy(i, j) > 0
                mi = mi + Pxy(i, j) * log2(Pxy(i, j) / (Px(i) * Py(j)));
            end
        end
    end
end   
%%