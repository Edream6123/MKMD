% 生成 15×366 的示例数据
% data = rand(15, 366);
m = 3; % 嵌入维数
p = 1; % 预测步长
% data =Data(:,1:366);
% 调用函数计算延时步数 3652 5549
max_tau = size(data,2);
tau_autocorr = autocorrelation_method_multi(data,max_tau);
fprintf('自相关法选择的延时步数: %d\n', tau_autocorr);

tau_mutual_info = mutual_information_method_multi(data,150);
fprintf('最小互信息法选择的延时步数: %d\n', tau_mutual_info);

tau_fill_factor = fill_factor_method_multi(data, m);
fprintf('填充因子法选择的延时步数: %d\n', tau_fill_factor);

% tau_noise_amplification = noise_amplification_method_multi(data, m, p);
% fprintf('噪声放大法选择的延时步数: %d\n', tau_noise_amplification);

tau_L_statistic = L_statistic_method_multi(data, m, max_tau);
fprintf('L - 统计量法选择的延时步数: %d\n', tau_L_statistic);

% 自相关法
function tau_autocorr = autocorrelation_method_multi(x, max_tau)
    num_dim = size(x, 1);
    % max_tau = 5549; % 修改为 150
    all_min_tau = zeros(num_dim, 1);
    for d = 1:num_dim
        [acf, lags] = autocorr(x(d, :));
        valid_lags = lags > 0 & lags <= max_tau;
        valid_acf = acf(valid_lags);
        [~, idx] = min(valid_acf);
        % 获取有效滞后索引
        valid_indices = find(valid_lags);
        % 取对应位置的索引
        all_min_tau(d) = valid_indices(idx);
    end
    tau_autocorr = round(mean(all_min_tau));
end

% 最小互信息法
function tau_mutual_info = mutual_information_method_multi(x, max_tau)
    num_dim = size(x, 1);
    % max_tau = 5549; % 修改为 150
    all_mi = zeros(num_dim, max_tau);
    for d = 1:num_dim
        for tau = 1:max_tau
            y = circshift(x(d, :), tau);
            all_mi(d, tau) = mutualinfo(x(d, :), y);
        end
    end
    % 这里简单取各维度最小互信息对应的平均滞后作为延时步数
    tau_per_dim = zeros(num_dim, 1);
    for d = 1:num_dim
        [~, idx] = min(all_mi(d, :));
        tau_per_dim(d) = idx;
    end
    tau_mutual_info = round(mean(tau_per_dim));
end

% 填充因子法
function tau_fill_factor = fill_factor_method_multi(x, m)
    num_dim = size(x, 1);
    max_tau = 182; % 修改为 150
    all_fill_factors = zeros(num_dim, max_tau);
    for d = 1:num_dim
        for tau = 1:max_tau
            Y = embed(x(d, :), m, tau);
            all_fill_factors(d, tau) = fillFactor(Y);
        end
    end
    tau_per_dim = zeros(num_dim, 1);
    for d = 1:num_dim
        [~, idx] = max(all_fill_factors(d, :));
        tau_per_dim(d) = idx;
    end
    tau_fill_factor = round(mean(tau_per_dim));
end

% 噪声放大法
function tau_noise_amplification = noise_amplification_method_multi(x, m, p, max_tau)
    num_dim = size(x, 1);
    % max_tau = 5549; % 修改为 150
    all_noise_amplification = zeros(num_dim, max_tau);
    for d = 1:num_dim
        for tau = 1:max_tau
            Y = embed(x(d, :), m, tau);
            % 这里简单模拟噪声放大计算，实际需要更复杂的预测模型
            all_noise_amplification(d, tau) = sum(abs(Y - mean(Y)));
        end
    end
    tau_per_dim = zeros(num_dim, 1);
    for d = 1:num_dim
        [~, idx] = min(all_noise_amplification(d, :));
        tau_per_dim(d) = idx;
    end
    tau_noise_amplification = round(mean(tau_per_dim));
end

% L - 统计量法
function tau_L_statistic = L_statistic_method_multi(x, m, max_tau)
    num_dim = size(x, 1);
    % max_tau = 5549; % 修改为 150
    all_L_statistics = zeros(num_dim, max_tau);
    for d = 1:num_dim
        for tau = 1:max_tau
            Y = embed(x(d, :), m, tau);
            % 这里简单模拟 L - 统计量计算，实际需要更复杂的公式
            all_L_statistics(d, tau) = sum(var(Y, 0, 1));
        end
    end
    tau_per_dim = zeros(num_dim, 1);
    for d = 1:num_dim
        [~, idx] = min(all_L_statistics(d, :));
        tau_per_dim(d) = idx;
    end
    tau_L_statistic = round(mean(tau_per_dim));
end

% 辅助函数：嵌入函数
function Y = embed(x, m, tau)
    N = length(x);
    Y = zeros(N - (m - 1)*tau, m);
    for i = 1:m
        Y(:, i) = x((1:N - (m - 1)*tau) + (i - 1)*tau);
    end
end

% 辅助函数：填充因子计算函数
function ff = fillFactor(Y)
    [N, m] = size(Y);
    vol = prod(max(Y) - min(Y));
    ff = N / vol;
end

% 辅助函数：互信息计算函数
function mi = mutualinfo(x, y)
    % 简单的互信息计算示例，实际需要更复杂的概率密度估计
    bins = 10;
    H = hist3([x(:) y(:)], [bins bins]); % 仅接收一个输出参数
    Pxy = H / numel(x);
    Px = sum(Pxy, 2);
    Py = sum(Pxy, 1);
    mi = 0;
    for i = 1:bins
        for j = 1:bins
            if Pxy(i, j) > 0
                mi = mi + Pxy(i, j) * log2(Pxy(i, j) / (Px(i) * Py(j)));
            end
        end
    end
end
    