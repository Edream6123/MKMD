% 读取数据文件
dataTable = readtable('merged_data_filled3.csv');

% 转换日期列为日期时间类型
dataTable.DATE = datetime(dataTable.DATE, 'InputFormat', 'yyyy/MM/dd');

% 筛选 2009 到 2023 年的数据
startYear = 2009;
endYear = 2023;
selectedData = dataTable(year(dataTable.DATE) >= startYear & year(dataTable.DATE) <= endYear, :);

% 初始化 15x366 的矩阵
data = zeros(15, 366);

% 遍历每一年
for yearIdx = 1:(endYear - startYear + 1)
    currentYear = startYear + yearIdx - 1;
    yearData = selectedData(year(dataTable.DATE) == currentYear, :);
    
    % 将 prcp 数据填充到矩阵的对应行
    for row = 1:height(yearData)
        % 使用 datenum 计算该日期是当年的第几天
        startOfYear = datetime(currentYear, 1, 1);
        dayOfYear = days(yearData.DATE(row) - startOfYear) + 1;
        data(yearIdx, dayOfYear) = yearData.PRCP(row);
    end
end