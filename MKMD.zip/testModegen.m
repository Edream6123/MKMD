%% 数据处理
data = readtable("merged_data_filled.csv", 'VariableNamingRule', 'preserve');
temp = data.("PRCP");
Data = temp(:)';  %  气温数据（每小时取一次）

%% 分解与模态计算
delt = 1;
delay = 8;  % 每小时取一次数据，延时步数为8
avg = mean(Data,2);
[eigval,Modes1,bo] = H_DMD(Data-avg,delay);
omega = log(diag(eigval))./delt;
Freal=imag(omega)./(2*pi);
% Freal(Freal < 1e-10) = NaN;  % 将零值或极小值替换为 NaN
[T,Im]=sort((1./Freal),'descend');  % 得到频率（降序）
% max_T = 1/T(2);
omega=omega(Im); 
Modes1=Modes1(:,Im); 
bo=bo(Im);  % 对应模态（降序）

%% 生成具体的模态
[nbx,nbt]=size(Data);
time=(0:nbt-1)*delt;
mode1 = 1;
mode2 = 8;  % 生成指定模态(已经按能量的降序进行排列了）
Psi=zeros(nbx,nbt,mode2-mode1+1);
for i=mode1:mode2
    psi = zeros(1,nbt);
    omeganow = omega(i);
    bnow = bo(i);
    parfor t=1:length(time) 
        psi(:,t)=exp(omeganow*time(t))*bnow;  % 并行计算结果
    end
    psi = Modes1(1:nbx,i)*psi;
    Psi(:,:,i) = psi;  % 输出模态
end

%% 绘图(模态实部（增长率））
FONTSIZE = 24;
TICKSIZE = 18;
mode1 = 1;
mode2 = 8;
for i = mode1:mode2
    figure;  
    plot(time , real(Psi(:,:,i)), 'LineWidth', 2); % Adjust LineWidth as needed  
    title({['Koopman Mode #' num2str(i)], ...  
           ['Period=' num2str(T(i),'%.2f') ' 小时']}, 'Interpreter', 'latex');  
    xlabel('Time [Minutes]', 'Interpreter', 'latex');  
    ylabel('Real Part of $\psi$', 'Interpreter', 'latex');  
    set(gca, 'TickLabelInterpreter', 'latex', 'FontSize', TICKSIZE);  
    grid on;  
end

%% 模态三维图
FONTSIZE = 24;
TICKSIZE = 18;
mode1 = 1;
mode2 = 12;
[nbx,nbt] = size(Data);
distance = delx*size(Data,1);

% 自定义颜色映射（可选，你可以根据需要修改）
custom_colormap = jet(256); 

for i = mode1:mode2
    [X,Y]=meshgrid(time,linspace(0,distance,nbx)); 
    figure;
    
    s1 = surfc(X,Y,real(Psi(:,:,i))); 
    set(s1,'LineStyle','none'); 
    
    data = real(Psi(:,:,i));
    min_val = min(data(:));
    max_val = max(data(:));
    cmin = min_val + 0.1 * (max_val - min_val);
    cmax = max_val - 0.1 * (max_val - min_val);
    caxis([cmin cmax]);
    
    colormap(custom_colormap);
    
    title_str = sprintf('Koopman Mode #%d,   Period=%.2f 天', i, T(i));
    title(title_str, 'fontsize', FONTSIZE, 'Interpreter', 'Latex');
    
    xlabel('Time [天]', 'Interpreter', 'latex'); 
    ylabel('year', 'Interpreter', 'latex');
    
    % 找到数据值最大的列索引
    [~, col_to_highlight] = max(sum(data, 1));
    
    highlight_x = X(:, col_to_highlight);
    highlight_y = Y(:, col_to_highlight);
    highlight_z = real(Psi(:, col_to_highlight, i));
    hold on;
    plot3(highlight_x, highlight_y, highlight_z, 'r', 'LineWidth', 2); 
    hold off;
    
    h = colorbar;
end
%% 单位圆
% 提取对角线上的元素
diag_eigval = diag(eigval);

% 计算原始特征值的实部、虚部和模
realPart = real(diag_eigval);
imagPart = imag(diag_eigval);
absEigval = abs(diag_eigval);

% 对特征值进行对数化处理
log_diag_eigval = log(diag_eigval);
log_realPart = real(log_diag_eigval);
log_imagPart = imag(log_diag_eigval);

% 设置颜色分类标准
colorStable = [0 0 1];  % 蓝色表示稳定
colorUnstable = [1 0 0];  % 红色表示不稳定
colorNeutral = [0 1 0];  % 绿色表示中性

% 初始化颜色数组
pointColors = zeros(length(diag_eigval), 3);

% 创建一个包含两个子图的图形窗口
figure;

% 绘制原始特征值的单位圆图
subplot(1, 2, 1);
hold on;

% 分类绘制原始特征值并记录颜色
for i = 1:length(diag_eigval)
    if absEigval(i) < 0.999  % 稳定
        pointColors(i, :) = colorStable;
        scatter(realPart(i), imagPart(i), 30, colorStable, 'filled');
    elseif absEigval(i) >= 0.999 && absEigval(i) <= 1.001  % 中性
        pointColors(i, :) = colorNeutral;
        scatter(realPart(i), imagPart(i), 30, colorNeutral, 'filled');
    else  % 不稳定
        pointColors(i, :) = colorUnstable;
        scatter(realPart(i), imagPart(i), 30, colorUnstable, 'filled');
    end
end

% 绘制单位圆
theta = linspace(0, 2*pi, 100);
plot(cos(theta), sin(theta), 'k--');  % 单位圆，虚线

% 设置图形属性
xlabel('Re(\lambda_i)');
ylabel('Im(\lambda_i)');
title('Eigenvalues Distribution on Unit Circle');
axis equal;
xlim([-1.2, 1.2]);
ylim([-1.2, 1.2]);
grid on;

% 绘制对数化特征值的图，以虚部为 x 轴
subplot(1, 2, 2);
hold on;

% 绘制对数化特征值，使用之前记录的颜色
for i = 1:length(log_diag_eigval)
    scatter(log_imagPart(i), log_realPart(i), 30, pointColors(i, :), 'filled');
end

% 设置图形属性
xlabel('Im(log(\lambda_i))');
ylabel('Re(log(\lambda_i))');
title('Logarithmized Eigenvalues Distribution');
xlim([-4, 4]);
ylim([-1.6, 0.2]);
grid on;

% 添加图例
hStable = scatter(nan, nan, 30, colorStable, 'filled');
hNeutral = scatter(nan, nan, 30, colorNeutral, 'filled');
hUnstable = scatter(nan, nan, 30, colorUnstable, 'filled');
legend([hStable, hNeutral, hUnstable], {'Stable', 'Neutral', 'Unstable'}, 'Location', 'best');

hold off;
%%
% eigval 是已经定义好的 Koopman 特征值矩阵
% 提取对角线上的特征值
diag_eigval = diag(eigval);

% 提取特征值的实部和虚部
real_part = real(diag_eigval);
imag_part = imag(diag_eigval);

% 对 T 取绝对值确保周期非负
period = abs(T(1:length(T),:));

% 使用 res 作为振幅
amplitudes = res(1:length(res),:);

% 增长率为特征值的实部
growth_rates = real_part;

% 找出振幅前二十的索引
[~, sortedIndices] = sort(amplitudes(1:length(amplitudes)/2,:), 'descend');
topTwentyIndices = sortedIndices(1:min(20, length(amplitudes)));

% 提取对应的模态编号、周期、振幅和增长率
topTwentyModes = topTwentyIndices;
topTwentyPeriods = period(topTwentyIndices);
topTwentyAmplitudes = amplitudes(topTwentyIndices);
topTwentyGrowthRates = growth_rates(topTwentyIndices);

% 检查变量长度是否一致
if length(topTwentyModes) ~= length(topTwentyPeriods) || ...
        length(topTwentyModes) ~= length(topTwentyAmplitudes) || ...
        length(topTwentyModes) ~= length(topTwentyGrowthRates)
    error('变量长度不一致，请检查数据。topTwentyModes: %d, topTwentyPeriods: %d, topTwentyAmplitudes: %d, topTwentyGrowthRates: %d', ...
        length(topTwentyModes), length(topTwentyPeriods), length(topTwentyAmplitudes), length(topTwentyGrowthRates));
end

% 创建表格
tableData = table(topTwentyModes, topTwentyPeriods, topTwentyAmplitudes, topTwentyGrowthRates, ...
    'VariableNames', {'Modes', 'Period(day)', 'Amplitude', 'Growth rate'});

% 显示表格
disp(tableData);

% 绘制类似图 (c) 的图形
figure;
scatter(period, amplitudes, 10, 'filled', 'MarkerFaceColor', [0.85 0.33 0.1]); % 橙色散点，标记大小设为 10
xlabel('Period (day)');
ylabel('Amplitude');
title('Amplitudes pertaining to the cycle of precipitation');

% 绘制右上角插图（假设月周期范围是 1 - 30 天）
monthly_indices = period >= 1 & period <= 30;
monthly_period = period(monthly_indices);
monthly_amplitudes = amplitudes(monthly_indices);

ax = gca;
inset_width = 0.2;
inset_height = 0.2;
inset_x = 0.6;
inset_y = 0.7;

inset_ax = axes('Position', [inset_x inset_y inset_width inset_height]);
scatter(monthly_period, monthly_amplitudes, 10, 'filled', 'MarkerFaceColor', [0.85 0.33 0.1]); % 标记大小设为 10
xlabel(inset_ax, 'Period(day)');
ylabel(inset_ax, 'Amplitude');

% 绘制类似图 (d) 的图形
figure;
scatter(amplitudes, growth_rates, 10, 'filled', 'MarkerFaceColor', [0.85 0.33 0.1]); % 橙色散点，标记大小设为 10
xlabel('Amplitude');
ylabel('Growth rate');
title('Amplitude corresponds to growth rate of precipitation');
%% 平均振幅和周期图
% 取前一半的数据
half_length = floor(length(res) / 2);
res_half = res(1:half_length);
T_half = T(1:half_length);

% 绘制折线图，不显示数据点
figure;
plot(T_half, res_half);

% 添加图标题和坐标轴标签
title('平均振幅与周期的关系（前一半数据）');
xlabel('周期');
ylabel('平均振幅');

% 显示网格线
grid on;

% 设置坐标轴范围
xlim([min(T_half) - 0.01, max(T_half) + 0.01]);
ylim([min(res_half), max(res_half) + 0.1]);
%%
max_f=14;
[nbx,nbt]=size(Data); % Get Data Size
Delt=1; % Sampling Frequency is 5 Mins
min_s=3;% Minimum Sampling of 15 Mins
min_f=min_s;% Minimum Forecasts of 15 Mins
max_s=max_f;% Maximum Sampling=Maximum Forecasting
Prediction{max(min_f,max_f),max(min_f,max_f)}=[]; % Preallocate
MAE=zeros(max(min_f,max_f),max(min_f,max_f)); % Preallocate
MRE=zeros(max(min_f,max_f),max(min_f,max_f)); % Preallocate
RMSE=zeros(max(min_f,max_f),max(min_f,max_f)); % Preallocate
SAE{max(min_f,max_f),max(min_f,max_f)}=[]; % Preallocate
TMAE{max(min_f,max_f),max(min_f,max_f)}=[]; % Preallocate
SMAE{max(min_f,max_f),max(min_f,max_f)}=[]; % Preallocate
AvgTMAE=zeros(max(min_f,max_f),max(min_f,max_f)); % Preallocate
AvgSMAE=zeros(max(min_f,max_f),max(min_f,max_f)); % Preallocate
%%
disp('Generating Forecasts for Various Forecasting and Sampling Windows')
tic
for f=min_f:min_f:max_f % Loop over Forecast Size Steps of 15 Mins
for s=min_s:min_s:max_s % Loop over Sampling Size in Steps of 15 Mins

P=[]; PE=[]; E=[]; I=[]; R=[]; Ptrue=[];

for t=s:f:nbt-f % Slide Window
if mod(t,100)==0 % Display Progress
disp(['Delay=' num2str(delay) ' Forecasting Window=' num2str(f)...
    ' Sampling Window=' num2str(s) ' Current Time=' num2str(t)...
    ' Out of ' num2str(nbt-f)])
end
omega=[]; eigval=[]; Modes1=[]; bo=[]; % Clear 
Xdmd=[]; Xtrain=[]; det=[]; % Clear 
Xtrain=Data(:,t-s+1:t); % Training Data
Xfor=Data(:,t+1:t+f); % Ground Truth of Forecasted Data 
det=mean(Xtrain,2);% Compute and Store Time Average
delay=14;% Set Delays to Max Possible
[eigval,Modes1,bo] = H_DMD(Xtrain-det,delay); % Compute HDMD
omega=log(diag(eigval))./delt; Modes1=Modes1(1:nbx,:);
parfor time=1:s+f
Xdmd(:,time)=diag(exp(omega.*(time-1)))*bo;% Evolve
end
Xdmd=Modes1*Xdmd; % Compute Reconstructed & Forecasted Data
Xdmd=real(Xdmd+det);% Add the Average Back in
P=[P Xdmd(:,s+1:end)];% Only Store the Forecast
Ptrue=[Ptrue Xfor];
end % Window Sliding

Prediction{f,s}=P;% Store Entire Forecast for These f,w Values
E=P-Data(:,s+1:s+size(P,2));% Compute Error Matrix
I=size(E,1)*size(E,2);% Get Total # Elements in Error matrix
MAE(f,s)=sum(sum(abs(E)))./I;% Compute MAE
MRE(f,s)=sum(sum(abs(E)./Data(:,s+1:s+size(P,2))))./I;% Compute MRE
RMSE(f,s)=sqrt(sum(sum(E.^2))./I);% Compute RMSE


SAE{f,s}=abs(E)./mean(Data(:,s+1:s+size(P,2)),2);% Compute SAE
TMAE{f,s}=mean(abs(E),1);% Compute TMAE
SMAE{f,s}=mean(abs(E),2);% Compute SMAE
AvgTMAE(f,s)=mean(TMAE{f,s});% Compute Avg of TMAE
AvgSMAE(f,s)=mean(SMAE{f,s});% Compute Avg of SMAE

end % End Sampling Window Loop
end % End Forecasting WIndow Loop
disp('Forecasts Generated')
toc
tic
disp('Generating Plots')
%%
