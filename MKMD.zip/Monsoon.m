% 定义插值后数据所在的文件夹路径
dataFolder = 'D:\matlab\bin\Koopman\datan2\已补全数据';

% 获取文件夹中所有 CSV 文件的列表
fileList = dir(fullfile(dataFolder, '*.csv'));

% 初始化一个空矩阵来存储数据
Data = [];

% 遍历每个文件
for i = 1:length(fileList)
    % 构建当前文件的完整路径
    filePath = fullfile(dataFolder, fileList(i).name);
    
    % 读取 CSV 文件
    dataTable = readtable(filePath);
    
    % 假设降水数据在 'PRCP' 列，你可以根据实际情况修改列名
    precipitationData = dataTable.PRCP;
    
    % 将当前站点的降水数据作为一行添加到 Data 矩阵中
    Data = [Data; precipitationData'];
end
data = Data(:,1:365*2);