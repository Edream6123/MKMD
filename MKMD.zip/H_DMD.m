%% Hankel-DMD
%Highway Traffic Dynamics: Data-Driven Analysis and Forecast 
%Allan M. Avila & Dr. Igor Mezic 2019
%University of California Santa Barbara
function [Eigval,Eigvec,bo,X,Y,H] = H_DMD(X,delay)
    % 输入参数检查
    if ~isnumeric(delay) || delay <= 0 || floor(delay) ~= delay || delay > size(X, 2)
        error('输入的 delay 必须是一个正整数，且不能超过 X 的列数。');
    end
    
    H = zeros(delay*size(X,1),size(X,2)-delay+1);
    for k=1:delay
        H(size(X,1)*(k-1)+1:size(X,1)*k,:) = X(:,k:end-delay+k);
    end
    
    % 处理 H 为空的情况
    if isempty(H)
        H = X;
    end
    
    % Split Data Matrix
    X1 = H(:,1:end-1); 
    X2 = H(:,2:end);
    
    % Compute Koopman Operator Approximation K
    [U,S,V] = svd(X1,'econ'); 
    % 处理奇异值，避免数值不稳定
    threshold = 1e-10;
    S(S > threshold) = 1./S(S > threshold);
    S(S <= threshold) = 0;
    K = U'*X2*V*S;        % Koopman近似值
    
    % Eigendecomposition of K
    [y,Eigval] = eig(K); 
    Eigvec = U*y;         % 特征向量
    
    % Project Initial Conditons on Eigenspace
    bo = pinv(Eigvec)*X1(:,1); % Koopman模态在初始空间的投影系数
    
    X = X1; 
    Y = X2;
end