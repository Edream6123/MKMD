import pandas as pd
import H_DMD

# 数据读取
data = pd.read_csv("D:\\桌面\\myPython\\Koopman\\Weather Data.csv")
temp = data["Temp_C"]
Data = temp.values

#


