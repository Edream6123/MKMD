import numpy as np
from scipy.linalg import svd, eig


def H_DMD(X, delay):
    # 构建 Hankel 矩阵
    rows, cols = X.shape
    H = np.zeros((delay * rows, cols - delay + 1))
    for k in range(delay):
        H[rows * k:rows * (k + 1), :] = X[:, k:cols - delay + k + 1]

    if H.size == 0:
        H = X

    # 划分数据矩阵
    X1 = H[:, :-1]
    X2 = H[:, 1:]

    # 计算 Koopman 算子近似 K
    U, S, Vh = svd(X1, full_matrices=False)
    S_inv = np.zeros_like(S)
    S_inv[S > 0] = 1.0 / S[S > 0]  # 计算奇异值的倒数
    K = U.T @ X2 @ Vh.T @ np.diag(S_inv)  # Koopman 近似值

    # K 的特征分解
    Eigval, y = eig(K)
    Eigvec = U @ y  # 特征向量

    # 将初始条件投影到特征空间
    bo = np.linalg.pinv(Eigvec) @ X1[:, 0]  # Koopman 模态在初始空间的投影系数

    return Eigval, Eigvec, bo, X1, X2, H

# 示例使用
# X 是你的输入数据矩阵，delay 是延迟嵌入的时间延迟
