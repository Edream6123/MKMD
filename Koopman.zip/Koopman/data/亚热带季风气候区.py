import os
import shutil
import re
import matplotlib.pyplot as plt

# 定义中国亚热带季风区的经纬度范围
min_lon = 110
max_lon = 120
min_lat = 25
max_lat = 35

# 定义基础路径
base_path = r'D:\matlab\bin\Koopman\datan2'
# 定义合并文件输出文件夹
merged_folder = os.path.join(base_path, 'merged_station_files')
# 定义亚热带季风区数据保存文件夹
target_folder = os.path.join(base_path, '亚热带季风区')

# 创建输出文件夹
if not os.path.exists(target_folder):
    os.makedirs(target_folder)

# 筛选亚热带季风区的站点数据
subtropical_stations = set()
lons = []
lats = []
for filename in os.listdir(merged_folder):
    # 从文件名中提取经纬度信息
    match = re.search(r'\((.*?),(.*?)\)', filename)
    if match:
        lon = float(match.group(1))
        lat = float(match.group(2))
        # 判断经纬度是否在中国亚热带季风区内
        if min_lon <= lon <= max_lon and min_lat <= lat <= max_lat:
            # 如果在范围内，则将文件复制到目标文件夹
            source_path = os.path.join(merged_folder, filename)
            target_path = os.path.join(target_folder, filename)
            try:
                shutil.copy2(source_path, target_path)
                print(f"Copied {filename} to {target_folder}")
            except PermissionError:
                print(f"权限不足，无法复制文件 {filename} 到 {target_folder}。请检查文件夹权限。")
            # 提取站点编号并添加到集合中
            station_number = filename.split('_')[0]
            subtropical_stations.add(station_number)
            lons.append(lon)
            lats.append(lat)

# 计算亚热带季风区的站点数量
station_count = len(subtropical_stations)
print(f"亚热带季风区的站点数量为: {station_count}")
print("文件筛选完成，亚热带季风区数据保存在:", target_folder)

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # Windows系统自带字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示异常

# 绘制散点图
plt.figure(figsize=(10, 8))
plt.scatter(lons, lats, alpha=0.5, color='red', s=50)

# 设置标题和坐标轴标签
plt.title('亚热带季风区站点分布散点图')
plt.xlabel('经度')
plt.xticks(rotation=45)
plt.ylabel('纬度')

# 显示网格线
plt.grid(True)

# 显示图表
plt.show()