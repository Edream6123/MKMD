import pandas as pd
import matplotlib.pyplot as plt


plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # Windows系统自带字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示异常
# 读取数据（假设文件为前一步生成的coordinates.csv）
df = pd.read_excel(r'D:\桌面\myPython\Koopman\data\CWTP station.xlsx')  # 如果列名是 '经度' 和 '纬度'
# 如果列名不同，请修改为实际列名，例如：
# df = pd.read_csv('coordinates_only.csv', names=['经度', '纬度'])

# 创建画布
plt.figure(figsize=(12, 8), dpi=150)

# 绘制散点图
plt.scatter(
    x=df['经度'],
    y=df['纬度'],
    s=30,          # 点大小
    c='#FF6B6B',   # 点颜色
    alpha=0.7,     # 透明度
    edgecolors='w' # 点边缘颜色
)

# 添加标题和标签
plt.title('气象站经纬度分布', fontsize=14, pad=20)
plt.xlabel('经度 (Longitude)', fontsize=12)
plt.ylabel('纬度 (Latitude)', fontsize=12)

# 网格线美化
plt.grid(True, linestyle='--', alpha=0.5)

# 保存图片
plt.savefig('scatter_plot2.png', bbox_inches='tight')
print("散点图已保存为 scatter_plot.png")
plt.show()