import os
import pandas as pd

# 定义数据集所在的文件夹路径
source_folder = r'D:\matlab\bin\Koopman\datan2\亚热带季风区'

# 遍历源文件夹中的所有文件
for filename in os.listdir(source_folder):
    file_path = os.path.join(source_folder, filename)
    try:
        # 读取文件
        df = pd.read_csv(file_path)

        # 提取日期列
        # 这里假设日期列名为 'DATE'，你可以根据实际情况修改
        date_column = df['DATE']

        # 将日期列转换为日期时间类型
        date_column = pd.to_datetime(date_column)

        # 计算理论上的日期范围
        min_date = date_column.min()
        max_date = date_column.max()
        total_days = (max_date - min_date).days + 1

        # 计算实际存在的日期数量
        existing_days = len(date_column.unique())

        # 计算缺省日期数量
        missing_days = total_days - existing_days

        # 计算缺省日期比例（缺省率）
        missing_ratio = missing_days / total_days

        print(f'文件 {filename} 的缺省率为 {missing_ratio * 100:.2f}%')

    except KeyError as key_err:
        print(f'文件 {filename} 中缺少日期列（DATE）: {key_err}')
    except Exception as general_err:
        print(f'处理文件 {filename} 时出现错误: {general_err}')
