import pandas as pd
import matplotlib.pyplot as plt

# 设置图片清晰度
plt.rcParams['figure.dpi'] = 300

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # Windows系统自带字体
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示异常
# 加载数据
df = pd.read_csv(r'D:\桌面\myPython\Koopman\data\coordinates_only.csv')

# 绘制散点图
plt.figure(figsize=(10, 8))
plt.scatter(df['经度'], df['纬度'], alpha=0.5, s=5)

# 设置标题和坐标轴标签
plt.title('经纬度散点图')
plt.xlabel('经度')
plt.xticks(rotation=45)
plt.ylabel('纬度')

# 显示网格线
plt.grid(True)

# 显示图表
plt.show()