import pandas as pd

# 读取数据（假设列名为 "经度" 和 "纬度"）
df = pd.read_csv("coordinates.csv")

# 统计经度出现次数
lon_counts = df["经度"].value_counts().reset_index()
lon_counts.columns = ["经度", "出现次数"]
max_lon = lon_counts[lon_counts["出现次数"] == lon_counts["出现次数"].max()]

# 统计纬度出现次数
lat_counts = df["纬度"].value_counts().reset_index()
lat_counts.columns = ["纬度", "出现次数"]
max_lat = lat_counts[lat_counts["出现次数"] == lat_counts["出现次数"].max()]

# 打印结果
print("==== 经度重复最多的情况 ====")
print(max_lon.to_string(index=False))

print("\n==== 纬度重复最多的情况 ====")
print(max_lat.to_string(index=False))