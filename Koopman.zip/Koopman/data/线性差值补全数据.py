import os
import pandas as pd

# 定义源文件夹和目标文件夹路径
source_folder = r'D:\matlab\bin\Koopman\datan2\亚热带季风区'
target_folder = r'D:\matlab\bin\Koopman\datan2\已补全数据'

# 定义日期范围
start_date = pd.to_datetime('2009-01-01')
end_date = pd.to_datetime('2024-03-11')
total_days = (end_date - start_date).days + 1

# 检查目标文件夹是否存在，不存在则创建
if not os.path.exists(target_folder):
    os.makedirs(target_folder)

# 用于存储每个站点的降水数据
station_precipitation = []
# 达标文件计数器
qualified_file_count = 0

# 定义异常值
outlier_value = 99.99

# 遍历源文件夹中的所有文件
for filename in os.listdir(source_folder):
    file_path = os.path.join(source_folder, filename)
    try:
        # 读取文件
        df = pd.read_csv(file_path)

        # 提取站台、日期、经度、纬度、降水数据列
        # 这里假设列名分别为 'STATION', 'DATE', 'LONGITUDE', 'LATITUDE', 'PRCP'
        # 你可以根据实际情况修改列名
        selected_df = df[['STATION', 'DATE', 'LONGITUDE', 'LATITUDE', 'PRCP']]

        # 使用loc明确索引操作
        selected_df.loc[:, 'DATE'] = pd.to_datetime(selected_df['DATE'])

        # 筛选指定日期范围内的数据，并确保包含 2023-12-31
        all_dates = pd.date_range(start=start_date, end=end_date)
        selected_df = selected_df[selected_df['DATE'].isin(all_dates)]

        # 将异常值替换为 NaN
        selected_df['PRCP'] = selected_df['PRCP'].replace(outlier_value, float('nan'))

        # 设置日期列为索引
        selected_df.set_index('DATE', inplace=True)

        # 按日期排序
        selected_df = selected_df.sort_index()

        # 计算缺省日期数量
        existing_days = len(selected_df.index.unique())
        missing_days = total_days - existing_days
        missing_ratio = missing_days / total_days

        if missing_ratio > 0.05:
            print(f'文件 {filename} 中缺省日期比例为 {missing_ratio * 100:.2f}%，超过 5%，跳过该文件。')
            continue

        # 获取第一行的站台、经度和纬度信息
        station = selected_df['STATION'].iloc[0]
        longitude = selected_df['LONGITUDE'].iloc[0]
        latitude = selected_df['LATITUDE'].iloc[0]

        # 以天为频率进行重采样，确保日期连续，且包含所有日期
        resampled_df = selected_df['PRCP'].reindex(all_dates, method=None).asfreq('D')

        # 使用线性插值法补全缺失的降水值
        interpolated_prcp = resampled_df.interpolate(method='linear')

        # 创建包含完整信息的 DataFrame
        final_df = pd.DataFrame({
            'STATION': station,
            'LONGITUDE': longitude,
            'LATITUDE': latitude,
            'PRCP': interpolated_prcp
        })

        # 重置索引
        final_df = final_df.reset_index()

        # 保存补全后的数据到目标文件夹
        output_file_path = os.path.join(target_folder, filename)
        final_df.to_csv(output_file_path, index=False)

        print(f'已成功补全并保存文件: {filename}')
        # 达标文件数量加 1
        qualified_file_count = qualified_file_count + 1

        # 存储当前站点的降水数据
        station_precipitation.append(interpolated_prcp.tolist())

    except KeyError as key_err:
        print(f'文件 {filename} 中缺少必要的列: {key_err}')
    except Exception as general_err:
        print(f'处理文件 {filename} 时出现错误: {general_err}')

# 将各站点的降水数据转换为 DataFrame，每个站点一行
Data = pd.DataFrame(station_precipitation)

print(f'所有文件处理完成，达标的文件数量为: {qualified_file_count}')
