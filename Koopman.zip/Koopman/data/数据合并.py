import os

# 定义基础路径
base_path = r'D:\matlab\bin\Koopman\datan2'
# 定义年份范围
start_year = 2009
end_year = 2023
# 定义合并文件输出文件夹
merged_folder = os.path.join(base_path, 'merged_station_files')

# 创建输出文件夹
if not os.path.exists(merged_folder):
    os.makedirs(merged_folder)

# 获取所有年份文件夹路径
year_folders = [os.path.join(base_path, str(year)) for year in range(start_year, end_year + 1)]

# 存储站点编号和对应文件路径的字典
station_files = {}

# 遍历每个年份文件夹
for year_folder in year_folders:
    if os.path.exists(year_folder):
        for filename in os.listdir(year_folder):
            file_path = os.path.join(year_folder, filename)
            if os.path.isfile(file_path):
                # 提取站点编号
                station_number = filename.split('_')[0]
                if station_number not in station_files:
                    station_files[station_number] = {}
                station_files[station_number][year_folder] = file_path

# 合并每个站点的文件
for station_number, year_file_dict in station_files.items():
    if len(year_file_dict) == (end_year - start_year + 1):
        # 确保每年都有文件
        first_file_path = list(year_file_dict.values())[0]
        original_filename = os.path.basename(first_file_path)
        output_file_path = os.path.join(merged_folder, original_filename)

        with open(output_file_path, 'w', encoding='utf-8') as outfile:
            first = True
            for year_folder in sorted(year_file_dict.keys()):
                file_path = year_file_dict[year_folder]
                with open(file_path, 'r', encoding='utf-8') as infile:
                    if first:
                        # 第一个文件写入表头
                        outfile.write(infile.read())
                        first = False
                    else:
                        # 后续文件跳过第一行（表头）
                        next(infile)
                        outfile.write(infile.read())

print("文件合并完成，合并后的文件保存在:", merged_folder)
