import os
import csv
import re
from pathlib import Path

# ------------------ 配置区域 -------------------
SOURCE_FOLDER = r"D:\matlab\bin\Koopman\datan2\2024" # 替换为存放CSV文件的文件夹路径
OUTPUT_COORD_CSV = "coordinates_only.csv"  # 仅保存经纬度的输出文件
# ----------------------------------------------

# 正则表达式匹配文件名中的经纬度
pattern = re.compile(r'.*_\((\d+\.\d+),(\d+\.\d+)\)\.csv$')


def extract_coordinates():
    """直接提取经纬度到独立文件"""
    coordinates = []

    # 遍历文件夹（含子文件夹）
    for root, _, files in os.walk(SOURCE_FOLDER):
        for file in files:
            if not file.lower().endswith('.csv'):
                continue  # 跳过非CSV文件

            # 提取经纬度
            match = pattern.search(file)
            if match:
                lon = round(float(match.group(1)), 6)
                lat = round(float(match.group(2)), 6)
                coordinates.append([lon, lat])

    # 写入独立文件
    with open(OUTPUT_COORD_CSV, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(["经度", "纬度"])  # 只有两列
        writer.writerows(coordinates)

    print(f"已提取 {len(coordinates)} 组经纬度到 {OUTPUT_COORD_CSV}")


if __name__ == "__main__":
    extract_coordinates()
    print("处理完成！输出文件格式示例：")
    print("经度,纬度")
    print("128.733333,45.966667")